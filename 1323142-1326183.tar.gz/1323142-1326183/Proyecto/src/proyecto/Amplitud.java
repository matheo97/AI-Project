/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 * 1 izq, 2 abajo, 3 derecha, 4 arriba
 */
package proyecto;
import java.util.ArrayList;

/**
 *
 * @author alejo
 */
public class Amplitud 

{
    private int totalNodos; 
    private int nodosExpandidos;
    private int costoSolucion; 
    private int profundidad;
    private int factorRamificacion;
    private int matrizIni[][]; //Matriz de estado inicial
    private ArrayList<Integer> caminoFinal; //lista de operadores acumulados de la solucion
    private Nodo raiz;
    private int xIni; // coordenada x inicial
    private int yIni; // coordenada y inicial
    private ArrayList<Nodo> cola;
    private Cargar leerArchivo; 
    private int encontro_meta;
    private int tamano;
    private ArrayList<String> matrices;
    String movimientos;
    String matrizInicial;
    int contador;

    
    
    
    public Amplitud()       
    {   
        contador = 1;
        matrizInicial= "";
        movimientos="";
        matrices = new ArrayList<>();
        profundidad =0;
        totalNodos=0;
        nodosExpandidos=1;
        costoSolucion=0;
        factorRamificacion=0;
        encontro_meta = 0;
        caminoFinal= new ArrayList<>();
        cola = new ArrayList<> ();
        leerArchivo = new Cargar();
        leerArchivo.leerMatriz("/home/alejo/Escritorio/Inteligencia Artificial/12/Proyecto/src/proyecto/matriz.txt");
        setxIni(leerArchivo.getInitx());
        setyIni(leerArchivo.getInity());
        setMatrizIni(leerArchivo.getMatriz());
        raiz= new Nodo(matrizIni, xIni, yIni);
        tamano = leerArchivo.getTamano();
        cola.add(raiz);
        totalNodos++;     
        for (int i = 0; i < matrizIni.length; i++) 
        {
            for (int j = 0; j < matrizIni.length; j++) 
            {
                matrizInicial = matrizInicial + matrizIni [i][j];
                
            }
            
        }
     
     
    }
    
    
    //  definicion gets and sets

    public String getMatrizInicial() {
        return matrizInicial;
    }

    public ArrayList<String> getMatrices() {
        return matrices;
    }
    
    

    public int getTamano()
    {
        return tamano;
    }

    public String getMovimientos() {
        return movimientos;
    }

    public int getProfundidad() {
        return profundidad;
    }

    public int getxIni() {
        return xIni;
    }

    public void setxIni(int xIni) {
        this.xIni = xIni;
    }

    public int getyIni() {
        return yIni;
    }

    public void setyIni(int yIni) {
        this.yIni = yIni;
    }
    
    

    public int getTotalNodos() {
        return totalNodos;
    }

    public void setTotalNodos(int totalNodos) {
        this.totalNodos = totalNodos;
    }

    public int getNodosExpandidos() {
        return nodosExpandidos;
    }

    public void setNodosExpandidos(int nodosExpandidos) {
        this.nodosExpandidos = nodosExpandidos;
    }

    public int getCostoSolucion() {
        return costoSolucion;
    }

    public void setCostoSolucion(int costoSolucion) {
        this.costoSolucion = costoSolucion;
    }

    public int getFactorRamificacion() {
        return factorRamificacion;
    }

    public void setFactorRamificacion(int factorRamificacion) {
        this.factorRamificacion = factorRamificacion;
    }

 
    



   

   

    public int[][] getMatrizIni() {
        return matrizIni;
    }

    public void setMatrizIni(int[][] matrizIni) {
        this.matrizIni = matrizIni;
    }

    public ArrayList<Integer> getCaminoFinal() {
        return caminoFinal;
    }

    public void setCaminoFinal(ArrayList<Integer> caminoFinal) {
        this.caminoFinal = caminoFinal;
    }
    
    // fin definicion gets and sets 
  

    boolean operadorValido(int operador)
    {
        Nodo nodo = cola.get(0);
        int tamMatriz = tamano; 
        int xPos = nodo.getPosiX();
        int yPos = nodo.getPosiY();
        int [][] matrizEstado = new int [tamano][tamano];
        
        for (int i = 0; i < tamano; i++) 
        {
            System.arraycopy(nodo.getEstado(i), 0, matrizEstado[i], 0, tamano);
                        
        }
       
        if(operador == 1 &&  (nodo.getOperador() != 3 || (nodo.getOperador() == 3 && nodo.getEncontro_meta() == 1) 
                || (nodo.getOperador() == 3 && nodo.getEncontro_tortuga() == 1)) && (yPos - 1) >= 0)
        {
            
            if(matrizEstado[xPos][yPos - 1] != 1)
            {  
                return true;
            }
                
                
                
        }       
        
        if(operador == 2 && (nodo.getOperador() != 4 || (nodo.getOperador() == 4 && nodo.getEncontro_meta() == 1)
                || (nodo.getOperador() == 4 && nodo.getEncontro_tortuga() == 1)) && (xPos+1) < tamMatriz)
        {
            if(matrizEstado[xPos+1][yPos] != 1)
            {
                return true;
            }
           
        }
        
        if(operador == 3 && (nodo.getOperador() != 1 || (nodo.getOperador() == 1 && nodo.getEncontro_meta() == 1)
                || (nodo.getOperador() == 1 && nodo.getEncontro_tortuga() == 1)) && (yPos+1) < tamMatriz)
        {
            
            if(matrizEstado[xPos][yPos+1] != 1)
            {
                return true;
            }
            
        }
        
        if(operador == 4  && (nodo.getOperador() != 2 || (nodo.getOperador() == 2 && nodo.getEncontro_meta() == 1)
                || (nodo.getOperador() == 2 && nodo.getEncontro_tortuga() == 1)) && (xPos - 1) >= 0)
        {
           
            if(matrizEstado[xPos-1][yPos] != 1)
            {
                
                return true;
            }
            
        }
        
        return false;
        
    }
    

    
    void generarSolucion()
    {
        
        //nuevos valores del nodo
        
        int operador = 0;
        int posiX = 0;
        int posiY = 0;   
        int [][] matrizEstado = new int[tamano][tamano];
     
        ArrayList<Integer> camino = new ArrayList<>();
      
        int profundidad = 0;
        Double costo = 0.0;
        int pasos = 0;
        int pasado = 2;
        
        Nodo nodo = cola.get(0);
        int w = 1;
        
        do
        {       
            
            
            encontro_meta = nodo.getEncontro_meta();   

            int x = 1;
            int ActualPos;
                   
                        
            while(x <= 4 && nodo.getCosto() >= 0)
            {
                //acpos= nodo.getPasado();
                if(operadorValido(x))
                {
                    
                    String temporal = "";

                     
                    for (int i = 0; i < tamano; i++) 
                    {
                       System.arraycopy(nodo.getEstado(i), 0, matrizEstado[i], 0, tamano);
                        
                    }
                    
                    
                    if(nodo.getPasado() == 7 || nodo.getPasado() == 4)
                    {
                        matrizEstado[nodo.getPosiX()][nodo.getPosiY()] = 2;
                        
                    }
                    else if(nodo.getPasado() == 6 && nodo.isMarlin())
                    {
                        matrizEstado[nodo.getPosiX()][nodo.getPosiY()] = 2;
                    }
                    else if(nodo.getPasado() == 5 && nodo.isDori())
                    {
                        matrizEstado[nodo.getPosiX()][nodo.getPosiY()] = 2;
                    }
                    else
                    {
                        matrizEstado[nodo.getPosiX()][nodo.getPosiY()] = nodo.getPasado();
                    }
                    
                    
                    
                    if(x == 1)
                    {   
                        posiX = nodo.getPosiX();
                        posiY = nodo.getPosiY() - 1;
                    }
                    if (x == 2)
                    {
                        posiX = nodo.getPosiX() + 1;
                        posiY = nodo.getPosiY();
                    }
                    if (x == 3)
                    {   
                        posiX = nodo.getPosiX();
                        posiY = nodo.getPosiY() + 1;   
                    }
                    if (x == 4)
                    {                        
                        posiX = nodo.getPosiX() - 1;
                        posiY = nodo.getPosiY();
                    }

                   
                   
                    ActualPos = matrizEstado[posiX][posiY];
                    
                    operador = x;
                    camino = (ArrayList<Integer>)nodo.getCamino().clone();                   
                    camino.add(x);
                    
                   
                   
                    profundidad = nodo.getProfundidad()+1;
                    pasos = nodo.getPasos();
                        
                    if(pasos > 0)
                    {
                        if(ActualPos == 2 || ActualPos == 4 || ActualPos == 5 || ActualPos == 6 || ActualPos == 7)
                        {
                            costo = nodo.getCosto() + 0.5;
                        }                       
                        else if(ActualPos == 3)
                        {
                            costo = nodo.getCosto() + 9.5;
                        }
                        else
                        {
                            costo = -1.0;
                        }
                        
                        pasos = pasos - 1;
                        
                    }
                    else if(ActualPos == 2 || ActualPos == 5 || ActualPos == 6 || ActualPos == 7)
                    {
                        costo = nodo.getCosto() + 1;
                        pasos = pasos - 1;
                    }
                    else if(ActualPos == 3)
                    {
                        costo = nodo.getCosto() + 10;
                        pasos = pasos - 1;
                    }
                    else if(ActualPos == 8)
                    {
                        costo = -1.0;
                    }
                    else if (ActualPos == 4)
                    {
                        pasos = 4;
                        costo = nodo.getCosto() + 1.0;
                    }
                    
                  
                    
                    pasado = matrizEstado[posiX][posiY];
                    matrizEstado[posiX][posiY] = 0;


                    int parcial = totalNodos +1;                    
                    for (int i = 0; i < matrizEstado.length; i++) 
                    {
                        for (int j = 0; j < matrizEstado.length; j++) 
                        {
                          
                            temporal += " " +matrizEstado[i][j];
                            
                        }
                        
                   
                    }
                    
                    Nodo nodo1 = new Nodo(temporal, operador, posiX, posiY, camino, profundidad, costo, pasos, pasado, tamano, nodo.isNemo(),nodo.isDori(),nodo.isMarlin(),0);
                    
                    
                    cola.add(nodo1);
                    totalNodos++;

                      
               }
                
                x++;
              
                
            }
           
           
            cola.remove(0);
            nodo = cola.get(0);
            nodosExpandidos++;
            
            if(nodo.getCosto() == -1)
            {
                cola.remove(0);
                nodo = cola.get(0);
                nodosExpandidos++;
            }
            
            
        }while(!nodo.esMeta());
     
    }
    
   
    
    void generarResultados()
    {
        String matriz ="";
        Nodo solucion = cola.get(0);
        ArrayList<Integer> operador = solucion.getCamino();
        int posX = xIni;
        int posY = yIni;
        int pasos = 0;
        double costoAcumulado = 0;
        int pasado = 2;
        movimientos = "(" + xIni + " , " + yIni + ") ";
        profundidad= operador.size();
        
        
        for (int i = 0; i < matrizIni.length; i++) 
        {
            for (int j = 0; j < matrizIni.length; j++)
            {
                matriz+= matrizIni[i][j];   
            }
            
        }
     
  
        
        matrices.add(matriz);
        matriz = "";
        boolean bandera = false;
        boolean metaNemo = false;
        boolean metaMarlin = false;
        
        for (int i = 0; i < operador.size(); i++) 
        {
            
            
            if(operador.get(i)== 1)
            {
                matrizIni[posX][posY] = pasado;
                //editar las coordenadas
                posY = posY - 1;
                pasado = matrizIni[posX][posY];
                
                matrizIni[posX][posY] = 0;

            } 
            if(operador.get(i)== 2)
            {
                matrizIni[posX][posY] = pasado;
                //editar las coordenadas
                posX = posX + 1;
                pasado = matrizIni[posX][posY];
                
                matrizIni[posX][posY] = 0;
                
            }
                
            if(operador.get(i)== 3)
            {
                matrizIni[posX][posY] = pasado;
                //editar las coordenadas
                posY = posY + 1;
                pasado = matrizIni[posX][posY];
                
                matrizIni[posX][posY] = 0;
                
            }
            if(operador.get(i)== 4)
            {
                matrizIni[posX][posY] = pasado;
                //editar las coordenadas
                posX = posX - 1;
                pasado = matrizIni[posX][posY];
                
                matrizIni[posX][posY] = 0;
                
            }
            
            if(pasado == 7 || metaNemo)
            {
                metaNemo = true;
                
                if(pasado == 7 && metaNemo)
                {
                    pasado = 2;
                }                
                
                if(pasado == 6 || metaMarlin)
                {
                    metaMarlin = true;

                    if(pasado == 6 && metaMarlin)
                    {
                        pasado = 2;
                    }
                    
                    if(pasado == 5)
                    {
                        pasado = 2;
                    }
                }   
            }
            
            if(pasado == 2 || pasado == 4)
            {
                pasado = 2;
            }
            
        for (int k = 0; k < matrizIni.length; k++) 
        {
            for (int j = 0; j < matrizIni.length; j++)
            {
                matriz+= matrizIni[k][j];   
            }
        }
            matrices.add(matriz);
            matriz="";
            if(contador == 4)
            {
                movimientos += "\n";
                contador =0;
            }
            movimientos += "---> ("  + posX + " , " + posY + ") ";  
            contador++;
        }
        
        //respuestas
        System.out.println("----Respuestas----");
        System.out.println("Movimientos: " );
        System.out.println(movimientos);
        System.out.println("Nodos expandidos: " + nodosExpandidos);
        System.out.println("Nodos creados: " + totalNodos);
        System.out.println("Total costo: " + solucion.getCosto());
        System.out.println("Factor de ramificacion promedio: " + (double)totalNodos/nodosExpandidos);
        
                
    }
    
}
