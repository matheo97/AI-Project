/*
 * Orden de movimientos para el robot:
1. izqueirda
2. abajo
3. derecha
4. arriba
 */
package proyecto;

import java.util.ArrayList;
import java.util.StringTokenizer;

/**
 *
 * @author 
 * Alejandro Rueda 1326183
 * Mateo Salazar 1323142
 */
public class Nodo
{
    private int estado [][];
    private int operador;
    private int posiX;
    private int posiY;
    //Referencia al padre
    private ArrayList<Integer> camino;
    private int profundidad;
    private Double costo;
    private int pasos;
    private int pasado;
    private boolean nemo;//
    private boolean dori;//
    private boolean marlin;//
    private int encontro_meta;
    private int encontro_tortuga;
    private int siguienteCamino;
    boolean metaParcial1;
    private double heuristica;
    private double gden;

    public double getGden() {
        return gden;
    }

    public void setGden(double gden) {
        this.gden = gden;
    }
    
    

    public double getHeuristica() {
        return heuristica;
    }

    public void setHeuristica(double heuristica) {
        this.heuristica = heuristica;
    }
    

    public int getSiguienteCamino() {
        return siguienteCamino;
    }

    public void setSiguienteCamino(int siguienteCamino) {
        this.siguienteCamino = siguienteCamino;
    }
    
    public int getEncontro_tortuga() {
        return encontro_tortuga;
    }

    public void setEncontro_tortuga(int encontro_tortuga) {
        this.encontro_tortuga = encontro_tortuga;
    }
  
    public int getPasado() {
        return pasado;
    }

    
    public void setPasado(int pasado) {
        this.pasado = pasado;
    }

    public ArrayList<Integer> getCamino()
    {    
        return camino;
    }

    public void setCamino(ArrayList<Integer> camino) {
        this.camino = camino;
    }

    public int getPasos() {
        return pasos;
    }

    public void setPasos(int pasos) {
        this.pasos = pasos;
    }


    public int[] getEstado(int i) {
        return estado[i];
    }

    public void setEstado(int[][] estado) {
        this.estado = estado;
    }

    public int getOperador() {
        return operador;
    }

    public void setOperador(int operador) {
        this.operador = operador;
    }

    public int getPosiX() {
        return posiX;
    }

    public void setPosiX(int posiX) {
        this.posiX = posiX;
    }

    public int getPosiY() {
        return posiY;
    }

    public void setPosiY(int posiY) {
        this.posiY = posiY;
    }

    public boolean isNemo() {
        return nemo;
    }

    public void setNemo(boolean nemo) {
        this.nemo = nemo;
    }

    public boolean isDori() {
        return dori;
    }

    public void setDori(boolean dori) {
        this.dori = dori;
    }

    public boolean isMarlin() {
        return marlin;
    }

    public void setMarlin(boolean marlin) {
        this.marlin = marlin;
    }

    public int getEncontro_meta() {
        return encontro_meta;
    }

    public void setEncontro_meta(int encontro_meta) {
        this.encontro_meta = encontro_meta;
    }
    
    public int getProfundidad() {
        return profundidad;
    }

    public void setProfundidad(int profundidad) {
        this.profundidad = profundidad;
    }

    public Double getCosto() {
        return costo;
    }

    public void setCosto(Double costo) {
        this.costo = costo;
    }

    public boolean isMetaParcial1() {
        return metaParcial1;
    }

    public void setMetaParcial1(boolean metaParcial1) {
        this.metaParcial1 = metaParcial1;
    }
    
    
        
    // fin de definicion gets and sets
    
    // definicion constructores 

    public Nodo(String temporal, int operador, int posiX, int posiY, ArrayList<Integer> camino, int profundidad, Double costo, int pasos, int pasado, int tamano, boolean nemo, boolean dori, boolean marlin, double heuristica)
    {
        StringTokenizer token;
        token = new StringTokenizer(temporal);
        estado = new int[tamano][tamano];
        
        for (int i = 0; i < estado.length; i++) 
        {
            for (int j = 0; j < estado.length; j++) 
            {
                estado[i][j]= Integer.parseInt(token.nextToken());
                
            }
            
        }
        
        this.operador = operador;
        this.posiX = posiX;
        this.posiY = posiY;
        this.camino = camino;
        this.profundidad = profundidad;
        this.costo = costo;
        this.pasos = pasos;
        this.pasado = pasado;
        this.nemo = nemo;
        this.dori = dori;
        this.marlin = marlin;
        this.heuristica=heuristica;
        gden= this.heuristica + this.costo;
        
    }

    public Nodo(int[][] estado, int posiX, int posiY) 
    {
        this.estado = estado;
        this.posiX = posiX;
        this.posiY = posiY;
        this.camino = new ArrayList<>();
        this.profundidad = 0;
        this.costo = 0.0;
        this.pasos = 0;
        this.pasado = 2;
        this.operador = 0;
        this.nemo = false;
        this.dori = false;
        this.marlin = false;
        this.encontro_meta = 0;
        this.encontro_tortuga = 0;
        this.metaParcial1 = true;
    }
    
    
    
    boolean esMeta()
    {
        if(pasado == 7 || nemo)
        {
            nemo = true;
            encontro_meta = 1;
            
            if(pasado == 7 && nemo)
            {
                camino.add(-1);
            }
            
            
            
            if(pasado == 6 || marlin)
            {
                marlin = true;
                encontro_meta = 1;
                
                if(pasado == 6 && marlin)
                {
                    camino.add(-1);                    
                }
               
                if(pasado == 5 || dori)
                {
                    dori = true;

                    return true;
                }
                else
                {
                    return false;
                }
            }
            else
            {
                return false;
            }
            
        }
        
        return false;
    }
    
    
    boolean hayCiclo(int posX, int posY, int operadorIni)
    {
        ArrayList<String> caminoFinal = new ArrayList();
        
        String n = "(" + posX +","+ posY + ")";
        caminoFinal.add(n);
        
        if(operadorIni == 3)
        {
            posY = posY - 1;
        }
        if(operadorIni == 4)
        {
            posX = posX + 1;
        }
        if(operadorIni == 1)
        {
            posY = posY + 1;
        }
        if(operadorIni == 2)
        {
            posX = posX - 1;
        }
                
        n = "(" + posX +","+ posY + ")";
        caminoFinal.add(n);
        
        
        for (int i = camino.size() - 1; i >= 0 && camino.get(i) != -1; i--) 
        {
            int x = camino.get(i);
            
            if(x == 3)
            {
                posY = posY - 1;
            }
            if(x == 4)
            {
                posX = posX + 1;
            }
            if(x == 1)
            {
                posY = posY + 1;
            }
            if(x == 2)
            {
                posX = posX - 1;
            }
            
            
            n = "(" + posX +","+ posY + ")";
            caminoFinal.add(n);
            
        }
        

        
        for (int i = 0; i < caminoFinal.size(); i++) 
        {
            String x = caminoFinal.get(i);
            
            for (int j = i+1; j < caminoFinal.size(); j++) 
            {
                String y = caminoFinal.get(j);
                
                if(x.equals(y))
                {
                   
                    return true;
                }
                
            }
            
        }
      
        return false;
    }
                                
 
}
