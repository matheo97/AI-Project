/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proyecto;

import java.util.*;


/**
 *
 * @author 
 * Alejandro Rueda 1326183
 * Mateo Salazar 1323142
 */
public class Proyecto 
{

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws InterruptedException
    {

        interfaz inter = new interfaz();
        
        inter.setVisible(true);

        
        
        
   }
    
 
   
    
    
    
}
