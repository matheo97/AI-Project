/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proyecto;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.StringTokenizer;
/**
 *
 * @author 
 * Alejandro Rueda 1326183
 * Mateo Salazar 1323142
 */
public class Cargar 
{
    
    private int initx;
    private int inity;
    private int nemox;
    private int nemoy;
    private int marlinx;
    private int marliny;
    private int dorix;
    private int doriy;
    
    private int matriz[][];
    private int tamano;

    public int getNemox() {
        return nemox;
    }

    public void setNemox(int nemox) {
        this.nemox = nemox;
    }

    public int getNemoy() {
        return nemoy;
    }

    public void setNemoy(int nemoy) {
        this.nemoy = nemoy;
    }

    public int getMarlinx() {
        return marlinx;
    }

    public void setMarlinx(int marlinx) {
        this.marlinx = marlinx;
    }

    public int getMarliny() {
        return marliny;
    }

    public void setMarliny(int marliny) {
        this.marliny = marliny;
    }

    public int getDorix() {
        return dorix;
    }

    public void setDorix(int dorix) {
        this.dorix = dorix;
    }

    public int getDoriy() {
        return doriy;
    }

    public void setDoriy(int doriy) {
        this.doriy = doriy;
    }

    public int getInitx() {
        return initx;
    }

    public void setInitx(int initx) {
        this.initx = initx;
    }

    public int getInity() {
        return inity;
    }

    public void setInity(int inity) {
        this.inity = inity;
    }

    public int[][] getMatriz() {
        return matriz;
    }

    public void setMatriz(int[][] matriz) {
        this.matriz = matriz;
    }

    public int getTamano() {
        return tamano;
    }

    public void setTamano(int tamano) {
        this.tamano = tamano;
    }
    
    public void leerMatriz (String texto)
    {
        String mensaje = "";
        String temp = "";
        File archivo = null;
        FileReader fr = null;
        BufferedReader br = null;
        StringTokenizer token;
        tamano=0;
        matriz  = null;
        int k=0;
        
        try
        {
            fr = new FileReader(new File(texto));
            br = new BufferedReader(fr);
            int i = 0;
            
            while((mensaje = br.readLine()) != null)
            {
                if(i == 0)
                {
                    setTamano(Integer.parseInt(mensaje));
                    matriz = new int [tamano][tamano];
                   
                    
                }
                if(i > 0)
                {
                    temp = mensaje;
                    
                    token = new StringTokenizer(temp);                    
                    for (int j = 0; j < tamano; j++) 
                    {
                          matriz [k][j]= Integer.parseInt(token.nextToken()); 
                          
                          if(matriz[k][j]==0)
                          {
                              initx=k;
                              inity=j;
                          }
                          else if(matriz[k][j]==7)
                          {
                              nemox=k;
                              nemoy=j;
                          }
                          else if(matriz[k][j]==6)
                          {
                              marlinx=k;
                              marliny=j;
                          }
                          else if(matriz[k][j]==5)
                          {
                              dorix=k;
                              doriy=j;
                          }
                              
                    }
                                
                    k++;
                }
                
                i++;
                
                }
            
        }
        catch(Exception x)
        {
            System.err.print("Error 1");
        }
        finally
        {
            
         try
         {                   
            if( null != fr)
            {  
               fr.close();    
            }                 
         }
         catch (Exception e2)
         {
             System.err.print("Error 2");
         }
        }       
        
        
    }
    
}
