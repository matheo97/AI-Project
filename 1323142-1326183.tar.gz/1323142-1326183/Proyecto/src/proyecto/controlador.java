/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proyecto;

import java.awt.Graphics;
import javax.swing.ImageIcon;

/**
 *
 * @author alejo
 */
public class controlador 

{
    int tama;
    ImageIcon nemo; 
    ImageIcon dori; 
    ImageIcon humano;
    ImageIcon marlin;
    ImageIcon piedras;
    ImageIcon tiburon;
    ImageIcon tortugas;
    ImageIcon libre;
    ImageIcon robot;
    String matriz;
    ImageIcon Robot;

    public controlador()
    {
        try 
        {
        nemo = new ImageIcon (new ImageIcon(getClass().getResource("/Imagenes/nemo.png")).getImage()); 
        dori = new ImageIcon(new ImageIcon(getClass().getResource("/Imagenes/dori.jpg")).getImage());               
        humano = new ImageIcon(new ImageIcon(getClass().getResource("/Imagenes/humano.png")).getImage());
        marlin = new ImageIcon(new ImageIcon(getClass().getResource("/Imagenes/marlin.jpg")).getImage());
        piedras = new ImageIcon(new ImageIcon(getClass().getResource("/Imagenes/piedras.jpg")).getImage());   
        tiburon = new ImageIcon(new ImageIcon(getClass().getResource("/Imagenes/tiburon.jpg")).getImage());
        tortugas = new ImageIcon(new ImageIcon(getClass().getResource("/Imagenes/tortugas.jpg")).getImage());
        libre =  new ImageIcon(new ImageIcon(getClass().getResource("/Imagenes/libre.jpg")).getImage());
        Robot =  new ImageIcon(new ImageIcon(getClass().getResource("/Imagenes/robot.png")).getImage());
      
        } catch (Exception e) {
            System.out.println("Problemas al cargar las imagenes");
        }
    }
    
   
    
    public void dibujar(Graphics g, int w, int q, String matri,int elTam )
    {  
        int x = 0;
        int y = 0;
       // matriz = matri;
        tama = elTam;
        int Desplazarx = w/tama;
        int desplazary = q/tama;
        int n = 0;
        

        
       
                    for (int j = 0; j < matri.length(); j++) 
                    {   
                       switch (matri.charAt(j))
                       {
                           case '0' : g.drawImage(Robot.getImage(), x, y ,Desplazarx,desplazary, null);
                                   x+= Desplazarx;
                                   break; 
                           case '1' : g.drawImage(piedras.getImage(), x, y ,Desplazarx,desplazary, null);
                                   x+= Desplazarx;
                                   break; 
                           case '2' : g.drawImage(libre.getImage(), x, y ,Desplazarx,desplazary, null);
                                   x+= Desplazarx;
                                   break; 
                           case '3' : g.drawImage(tiburon.getImage(), x, y ,Desplazarx,desplazary, null);
                                   x+= Desplazarx;
                                   break;  
                           case '4' : g.drawImage(tortugas.getImage(), x, y ,Desplazarx,desplazary, null);
                                   x+= Desplazarx;
                                   break;   
                           case '5' : g.drawImage(dori.getImage(), x, y ,Desplazarx,desplazary, null);
                                   x+= Desplazarx;
                                   break;
                           case '6' : g.drawImage(marlin.getImage(), x, y ,Desplazarx,desplazary, null);
                                   x+= Desplazarx;
                                   break; 
                           case '7' : g.drawImage(nemo.getImage(), x, y ,Desplazarx,desplazary, null);
                                   x+= Desplazarx;
                                   break;   
                           case '8' : g.drawImage(humano.getImage(), x, y ,Desplazarx,desplazary, null);
                                   x+= Desplazarx;
                                   break; 
                           default: System.out.println("error en numero");
                                   x+= Desplazarx;
                           break;
                       }
                       n++;
                        if(n == tama)
                        {
                        y+=desplazary;
                        x=0; 
                        n = 0;
                        }
                    }
                    
                
    }
          
}
